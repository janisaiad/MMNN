Low-rank NTK experiment code bundle
Created: 2026-05-06T13:27:34
Project root: <anonymized project root>

Contents:
- experiments/feynman/run_lowrank_ntk_paper_experiments.py
  Proxy experiments for rank-defect, Haar covariance, scalar endpoint constants, operator scaling, and RF-LR memory.
- experiments/feynman/run_true_finite_ntk_validation_fixed.py
  True empirical NTK operator/rank-defect validation and full-rank matching checks.
- experiments/feynman/run_true_finite_ntk_cumulant_validation.py
  Direct finite-network cumulant sweeps for V/C/A log-log diagnostics.
- experiments/table/mnist_mmnn_vs_mlp.py
  MNIST MLP vs low-rank MMNN training benchmark.
- experiments/table/icml_rebuttal_experiments.py
  Additional MNIST multi-rank/multi-seed helper used around the low-rank table experiments.
- experiments/table/mnist_mmnn_vs_mlp/plot_mnist_perf_vs_params.py
  MNIST parameter-efficiency plot script used for the table/figure values.
- experiments/table/mnist_mmnn_vs_mlp/run_fixWbFalse.sh
  Helper shell script for trainable-factor MNIST run when present.
- experiments/table/mnist_mmnn_vs_mlp/results.md, results.json, plot_data.json
  Compact MNIST run summaries and plotting data included for reproducibility of the table values.

Run paths are relative to the repository root. No local machine path is required.

Missing requested/expected files skipped:
- none
